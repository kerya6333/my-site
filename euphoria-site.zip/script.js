
const users = {
    'kerya_TL_new': { password: 'Abdram6333', balance: '26000000' },
    'kerya_refka_new': { password: 'Abdram6333', balance: '5500000' },
    'kerya_refka2_new': { password: 'Abdram6333', balance: '3000000' }
};

function login() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    const errorDisplay = document.getElementById('error');

    if (users[username] && users[username].password === password) {
        localStorage.setItem('loggedUser', username);
        window.location.href = 'dashboard.html';
    } else {
        errorDisplay.textContent = 'Неверный логин или пароль';
    }
}

if (window.location.pathname.includes('dashboard.html')) {
    const user = localStorage.getItem('loggedUser');
    if (user && users[user]) {
        document.getElementById('userDisplay').textContent = user;
        document.getElementById('balanceDisplay').textContent = parseFloat(users[user].balance).toLocaleString('ru-RU');
    } else {
        window.location.href = 'index.html';
    }
}
