const accounts = {
    kerya_TL_new: { password: 'Abdram6333', balance: 26000000 },
    kerya_refka_new: { password: 'Abdram6333', balance: 5500000 },
    kerya_refka2_new: { password: 'Abdram6333', balance: 3000000 }
};

function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (accounts[username] && accounts[username].password === password) {
        localStorage.setItem('username', username);
        localStorage.setItem('balance', accounts[username].balance);
        window.location.href = 'dashboard.html';
    } else {
        document.getElementById('error').innerText = 'Неверный логин или пароль';
    }
}

if (window.location.pathname.includes('dashboard.html')) {
    const user = localStorage.getItem('username');
    const balance = localStorage.getItem('balance');
    if (user && balance) {
        document.getElementById('user').innerText = user;
        document.getElementById('balance').innerText = Number(balance).toLocaleString('ru-RU');
    } else {
        window.location.href = 'index.html';
    }
}
